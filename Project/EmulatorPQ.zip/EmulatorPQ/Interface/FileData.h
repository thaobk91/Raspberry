/*
 * FileData.h
 *
 *  Created on: Feb 27, 2018
 *      Author: thaohuyen
 */

#ifndef INTERFACE_FILEDATA_H_
#define INTERFACE_FILEDATA_H_

void vFileData_getHAQI( char *HAQI, unsigned char Day, unsigned char Hour );


void vFileData_getDAQI( char *DAQI, unsigned char Day, unsigned char Hour );



#endif /* INTERFACE_FILEDATA_H_ */

















